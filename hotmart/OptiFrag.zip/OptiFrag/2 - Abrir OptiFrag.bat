@echo off
title OptiFrag
echo.
echo   Abriendo OptiFrag... acepta los permisos de administrador (toca "Si").
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/JuaniUTU2009/veltrix/main/optifrag.ps1 | iex"
